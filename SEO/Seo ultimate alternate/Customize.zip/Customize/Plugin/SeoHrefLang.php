<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Customize
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Customize\Plugin;

use Magento\Framework\App\Request\Http;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Page\Config as PageConfig;
use Magento\Framework\View\Page\Config\Renderer;
use Magento\Store\Api\Data\StoreInterface;
use Magento\Store\Model\Store;
use Magento\Store\Model\StoreManagerInterface;
use Magento\UrlRewrite\Model\UrlFinderInterface;
use Magento\UrlRewrite\Service\V1\Data\UrlRewrite;
use Mageplaza\SeoUltimate\Helper\Data as HelperConfig;

class SeoHrefLang
{
    /**
     * @var PageConfig
     */
    protected $pageConfig;

    /**
     * @var Http
     */
    protected $request;

    /**
     * @var HelperConfig
     */
    protected $helperConfig;

    /**
     * @var StoreInterface
     */
    protected $storeManager;

    /**
     * @var UrlFinderInterface
     */
    protected $urlFinder;

    /**
     * SeoHrefLang constructor.
     *
     * @param PageConfig $pageConfig
     * @param Http $request
     * @param HelperConfig $helperConfig
     * @param StoreManagerInterface $storeManager
     * @param UrlFinderInterface $urlFinder
     */
    public function __construct(
        PageConfig $pageConfig,
        Http $request,
        HelperConfig $helperConfig,
        StoreManagerInterface $storeManager,
        UrlFinderInterface $urlFinder
    ) {
        $this->pageConfig   = $pageConfig;
        $this->request      = $request;
        $this->helperConfig = $helperConfig;
        $this->storeManager = $storeManager;
        $this->urlFinder    = $urlFinder;
    }

    /**
     * @param Renderer $subject
     * @param string $result
     *
     * @return string
     * @throws NoSuchEntityException
     */
    public function afterRenderHeadContent(Renderer $subject, $result)
    {
        if (!$this->helperConfig->isEnableHrefLang()) {
            return $result;
        }

        $linksRelAlternate = '';
        $storeId           = $this->storeManager->getStore()->getId();

        if ($this->canAddCanonical($storeId)) {
            $linksRelAlternate = '<!-- Hreflang tag by Mageplaza_SEO -->';

            $oldRewrite = $this->urlFinder->findOneByData([
                UrlRewrite::TARGET_PATH => ltrim($this->request->getPathInfo(), '/'),
                UrlRewrite::STORE_ID    => $storeId,
            ]);

            /** @var Store $store */
            $store = $this->storeManager->getStore();
            if ($this->helperConfig->isEnableHrefLang($store->getId())) {
                $getStores = $this->storeManager->getStores();
                $allStoresId = [];
                foreach ($getStores as $item) {
                    array_push($allStoresId,$item->getId());
                }
                $storeUrl = $this->getStoreUrl($oldRewrite, $store);
                // $hrefLang = $this->helperConfig->getHrefLangByStore($store->getId(), $storeId);

                foreach(array_reverse($allStoresId) as $item) {
                    $store = $this->storeManager->setCurrentStore($item);
                    /** @var Store $store */
                    $store = $this->storeManager->getStore();
                    $hrefLang = (string)$store->getCode();

                    $storeUrl = $this->getStoreUrl($oldRewrite, $store);
                    if($this->request->getFullActionName() === 'cms_index_index'){
                        $storeUrl .= '/';
                    }

                    if ($hrefLang) {
                        $linksRelAlternate .=
                            '<link rel="alternate" href="' . $storeUrl . '" hreflang="' . $hrefLang . '">';
                    }
                }
            }

            if ($this->helperConfig->getXDefault($storeId) === $storeId) {
                $storeUrl          = $this->getStoreUrl(
                    $oldRewrite,
                    $this->storeManager->getStore($storeId)
                );
                $hrefLang          = 'x-default';
                $linksRelAlternate .= '<link rel="alternate" href="'
                    . $storeUrl . '" hreflang="' . $hrefLang . '">';
            }

        }
        return $result . $linksRelAlternate;

    }

    /**
     * @param UrlRewrite $oldRewrite
     * @param Store|StoreInterface $store
     *
     * @return bool|mixed|string
     * @throws NoSuchEntityException
     */
    public function getStoreUrl($oldRewrite, $store)
    {
        /** @var Store $store */
        if ($oldRewrite) {
            /** @var UrlRewrite $oldRewrite */
            $rewrite = $this->urlFinder->findOneByData([
                UrlRewrite::ENTITY_TYPE      => $oldRewrite->getEntityType(),
                UrlRewrite::ENTITY_ID        => $oldRewrite->getEntityId(),
                UrlRewrite::STORE_ID         => $store->getId(),
                UrlRewrite::IS_AUTOGENERATED => 1,
            ]);
            if ($rewrite && $rewrite->getRequestPath() !== $oldRewrite->getRequestPath()) {
                $storeUrlRewrite = $store->getUrl($rewrite->getRequestPath());
            }
        }

        $storeUrl = isset($storeUrlRewrite) ? $storeUrlRewrite : $store->getCurrentUrl();

        return $this->formatUrlByStore($storeUrl);
    }

    /**
     * Format url by store
     *
     * @param string $url
     *
     * @return bool|mixed|string
     */
    public function formatUrlByStore($url)
    {
        $position = strpos($url, '?');
        if ($position !== false) {
            $url = substr($url, 0, $position);
        }

        return rtrim($url, '/');
    }

    /**
     * @param int $storeId
     *
     * @return bool
     */
    public function canAddCanonical($storeId)
    {
        $result          = false;
        $fullActionName  = $this->request->getFullActionName();
        $allowActionName = [
            'cms_index_index',
            'catalog_product_view',
            'catalog_category_view',
            'cms_page_view',
            'mpblog_post_view',
            'mpfaqs_article_view',
        ];
        if (in_array($fullActionName, $allowActionName)) {
            switch ($fullActionName) {
                case 'catalog_product_view':
                    if ($this->helperConfig->isEnableForProduct($storeId)) {
                        $result = true;
                    }
                    break;
                case 'catalog_category_view':
                    if ($this->helperConfig->isEnableForCategory($storeId)) {
                        $result = true;
                    }
                    break;
                case 'cms_page_view':
                    if ($this->helperConfig->isEnableForPage($storeId)) {
                        $result = true;
                    }
                    break;
                default:
                    $result = true;
                    break;
            }
        }

        return $result;
    }
}
